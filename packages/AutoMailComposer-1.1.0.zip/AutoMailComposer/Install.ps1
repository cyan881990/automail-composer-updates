$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'AutoMailComposer'
$candidates = @()
$pythonCommand = Get-Command pythonw.exe -ErrorAction SilentlyContinue
if ($pythonCommand) { $candidates += $pythonCommand.Source }
$codexRuntime = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\pythonw.exe'
if (Test-Path -LiteralPath $codexRuntime) { $candidates += $codexRuntime }
$python = $null
foreach ($candidate in $candidates) {
    $console = Join-Path (Split-Path $candidate) 'python.exe'
    & $console -c 'import tkinter,ssl'
    if ($LASTEXITCODE -eq 0) { $python = $candidate; break }
}
if (-not $python) { throw 'Can Python 3.11+ co Tkinter. Cai Python tu python.org, chon Add Python to PATH, roi chay Install.cmd lai.' }
New-Item -ItemType Directory -Path $target -Force | Out-Null
foreach ($file in @('composer.py','updater.py','launcher.py','version.json','README.txt')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $target $file) -Force
}
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Auto Mail Composer.lnk'))
$shortcut.TargetPath = $python
$shortcut.Arguments = '"' + (Join-Path $target 'launcher.py') + '"'
$shortcut.WorkingDirectory = $target
$shortcut.Save()
Write-Host 'Da cai dat. Mo Auto Mail Composer tren Desktop. Dang nhap Codex bang: codex login'
