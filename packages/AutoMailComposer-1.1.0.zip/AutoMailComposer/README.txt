AUTO MAIL COMPOSER - WINDOWS

1. Can Python 3.11+ voi Tkinter (python.org) va Codex CLI da dang nhap.
   Installer cung nhan Python runtime san co cua Codex Desktop.
2. Giai nen toan bo ZIP, chay Install.cmd. Mo shortcut Auto Mail Composer tren Desktop.
3. Trong terminal, chay codex login neu chua dang nhap. App tu tim codex.exe cua Codex Desktop.
4. Nhap URL Auto Mail, tai khoan va mat khau. Mat khau chi giu trong RAM.
5. Tren web app: tao san pham, sua/tao chien dich, chon san pham va mailbox, bam Lap ke hoach.
6. Trong Composer: ket noi, chon chien dich, Nhan bao cao.
7. Chon so khach moi luot; dong y chuyen du lieu bao cao toi Codex; bam Soan & dong bo.
   Chi du lieu profile va san pham can thiet duoc gui toi Codex. Khong gui khoa LeadAtlas/SSH.
   Khong duyet web hay tu bia thong tin khach. Link va anh duoc render boi server.
8. Tao lich & chuyen ve app. Server kiem tra quota, trung khach, khoang cach va agent.
9. Tren web app, kiem tra va Kich hoat ke hoach. Composer KHONG tu gui SMTP.

Quota = 0: van co the soan noi dung, nhung khong the tao lich gui that.
Bao cao cu sau khi doi san pham/chien dich bi tu choi. Lap lai bao cao.
Mat mang khi dong bo: ban nhap chua xac nhan giu tai LocalAppData/AutoMailComposer/drafts.
Chay lai cung bao cao de tiep tuc; API nhan lap lai cung noi dung mot cach idempotent.
Khong bam Lap ke hoach lai neu muon tiep tuc bao cao cu.
Chu y: khong dong app khi dang soan. Codex co the tinh vao han muc tai khoan ChatGPT cua ban.

Go cai dat: xoa shortcut va thu muc LocalAppData/AutoMailComposer sau khi sao luu ban nhap can giu.
Tai lieu Codex: https://developers.openai.com/codex/noninteractive/


CAP NHAT TU DONG (tu 1.1.0)
Shortcut khoi dong qua launcher.py, kiem tra stable.json tren repository public
https://github.com/cyan881990/automail-composer-updates
Goi ZIP phai tro den commit GitHub co dinh va khop SHA-256 + kich thuoc.
Kiem tra khi mo app va moi 6 gio khi ranh. Ban moi duoc tai ve versions/,
khong ghi de file dang chay, ap dung khi mo lai. Co nut Kiem tra cap nhat.
Mat mang/goi hong: tiep tuc ban cu. Khoi dong ban moi bi loi: quay lai ban truoc.
Khong bao gio gui thong tin khach hang, cookie hay mat khau den repo cap nhat.
Khong xoa drafts hoac phien ban truoc khi cap nhat.
