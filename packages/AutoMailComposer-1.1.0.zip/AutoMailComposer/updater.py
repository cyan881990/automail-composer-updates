"""Versioned updater, restricted to the owner's public distribution repository."""
import hashlib, hmac, io, json, os, re, shutil, stat, sys, tempfile, time, uuid, zipfile
from pathlib import Path
from urllib.request import Request, build_opener, HTTPRedirectHandler

REPOSITORY='cyan881990/automail-composer-updates'
MANIFEST_URL='https://raw.githubusercontent.com/'+REPOSITORY+'/main/stable.json'
MAX_PACKAGE=20*1024*1024
FILES={'composer.py','updater.py','launcher.py','version.json','Install.ps1','Install.cmd','README.txt'}
class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise ValueError('Update redirects are not allowed')
def version(value):
    if not isinstance(value,str) or not re.fullmatch(r'(0|[1-9]\d{0,4})\.(0|[1-9]\d{0,4})\.(0|[1-9]\d{0,4})',value):raise ValueError('Invalid release version')
    return tuple(map(int,value.split('.')))
def fetch_bytes(url,limit):
    with build_opener(NoRedirect()).open(Request(url,headers={'User-Agent':'AutoMailComposer-Updater/1','Cache-Control':'no-cache'}),timeout=8) as response:
        data=response.read(limit+1)
    if len(data)>limit:raise ValueError('Update exceeds size limit')
    return data
def read_json(path,default=None):
    try:return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError,ValueError):return default
def atomic_json(path,value):
    path=Path(path);temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:temp.write_text(json.dumps(value),encoding='utf-8');os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)
def current_directory(root):
    root=Path(root);pointer=read_json(root/'current.json',{})
    try:
        selected=pointer.get('version')
        if selected:
            version(selected);folder=root/'versions'/selected
            if (folder/'composer.py').is_file() and (folder/'version.json').is_file() and version(read_version(folder))>=version(read_version(root)):return folder
    except (ValueError,AttributeError,TypeError):pass
    return root
def read_version(folder):
    value=read_json(Path(folder)/'version.json',{}).get('version','0.0.0');version(value);return value
def validate_manifest(m):
    if not isinstance(m,dict) or m.get('schema')!=1:raise ValueError('Unsupported update manifest')
    version(m.get('version'))
    if not re.fullmatch(r'[a-f0-9]{64}',str(m.get('sha256',''))):raise ValueError('Invalid package checksum')
    if type(m.get('size')) is not int or not 0<m['size']<=MAX_PACKAGE:raise ValueError('Invalid package size')
    pattern=r'https://raw\.githubusercontent\.com/'+re.escape(REPOSITORY)+r'/[a-f0-9]{40}/packages/AutoMailComposer-'+re.escape(m['version'])+r'\.zip'
    if not re.fullmatch(pattern,str(m.get('url',''))):raise ValueError('Package is not pinned to the release repository commit')
    if m.get('min_python')!=[3,11]:raise ValueError('Unsupported Python requirement')
    if sys.version_info<(3,11):raise ValueError('Python 3.11+ required')
def stage_update(root,fetcher=fetch_bytes):
    root=Path(root);root.mkdir(parents=True,exist_ok=True);lock=root/'update.lock';fd=None;acquired=False
    try:
        try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);acquired=True
        except FileExistsError:
            if time.time()-lock.stat().st_mtime>900:lock.unlink(missing_ok=True)
            return {'status':'busy'}
        os.close(fd);fd=None
        m=json.loads(fetcher(MANIFEST_URL,16384));validate_manifest(m)
        selected=current_directory(root);installed=read_version(selected)
        if version(m['version'])<=version(installed):return {'status':'current','version':installed}
        if m['version'] in read_json(root/'rejected.json',[]):return {'status':'rejected','version':m['version']}
        package=fetcher(m['url'],MAX_PACKAGE)
        if len(package)!=m['size'] or not hmac.compare_digest(hashlib.sha256(package).hexdigest(),m['sha256']):raise ValueError('Package SHA-256 mismatch')
        versions=root/'versions';versions.mkdir(exist_ok=True);target=versions/m['version']
        if target.exists():
            if read_json(target/'release.json',{}).get('sha256')!=m['sha256']:raise ValueError('Version already exists with different contents')
        else:
            with tempfile.TemporaryDirectory(prefix='stage-',dir=versions) as directory:
                staging=Path(directory)/'app';staging.mkdir()
                with zipfile.ZipFile(io.BytesIO(package)) as archive:
                    expected={'AutoMailComposer/'+name for name in FILES};names=archive.namelist()
                    if len(names)!=len(expected) or set(names)!=expected:raise ValueError('Unexpected files in update package')
                    for info in archive.infolist():
                        if info.file_size>2*1024*1024 or stat.S_ISLNK(info.external_attr>>16):raise ValueError('Unsafe update archive entry')
                        data=archive.read(info)
                        if info.filename.endswith('.py'):compile(data,info.filename,'exec')
                        (staging/Path(info.filename).name).write_bytes(data)
                if read_version(staging)!=m['version']:raise ValueError('Manifest/package version mismatch')
                atomic_json(staging/'release.json',m);os.rename(staging,target)
        previous=selected.name if selected!=root else 'bundled'
        atomic_json(root/'current.json',{'version':m['version'],'previous':previous})
        return {'status':'staged','version':m['version']}
    finally:
        if fd is not None:os.close(fd)
        if acquired:lock.unlink(missing_ok=True)

def rollback(root,failed):
    root=Path(root);pointer=read_json(root/'current.json',{});rejected=read_json(root/'rejected.json',[])
    if failed not in rejected:rejected.append(failed)
    atomic_json(root/'rejected.json',rejected)
    if pointer.get('version')!=failed:return
    previous=pointer.get('previous','bundled')
    if previous=='bundled':atomic_json(root/'current.json',{})
    else:version(previous);atomic_json(root/'current.json',{'version':previous,'previous':'bundled'})
