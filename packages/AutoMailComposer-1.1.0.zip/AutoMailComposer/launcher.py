"""Installed shortcut entry point; never replaces files in a running app."""
import os, runpy, sys
from pathlib import Path
from updater import stage_update,current_directory,read_version,rollback,atomic_json

def main():
    root=Path(__file__).resolve().parent;os.environ['AUTOMAIL_INSTALL_ROOT']=str(root)
    try:stage_update(root)
    except Exception as error:atomic_json(root/'update-status.json',{'status':'failed','message':str(error)[:300]})
    selected=current_directory(root)
    try:runpy.run_path(str(selected/'composer.py'),run_name='__main__')
    except Exception:
        if selected==root:raise
        rollback(root,read_version(selected));fallback=current_directory(root)
        atomic_json(root/'update-status.json',{'status':'rollback','message':'Bản mới chưa khởi động được; đã khôi phục bản trước.'})
        runpy.run_path(str(fallback/'composer.py'),run_name='__main__')
if __name__=='__main__':main()
